from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

# In-memory storage for registrants (use a database in production)
registrants = []

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name")
        sport = request.form.get("sport")

        if name and sport:
            registrants.append({"name": name, "sport": sport})
            return redirect(url_for("registrants"))

    return render_template("register.html")

@app.route("/registrants")
def registrants_list():
    return render_template("registrants.html", registrants=registrants)

if __name__ == "__main__":
    app.run(debug=True)
